#!/usr/bin/env python3


from brain_games import cli


def main():
    cli.welcome_user('Welcome to the Brain Games!')


if __name__ == '__main__':
    main()
