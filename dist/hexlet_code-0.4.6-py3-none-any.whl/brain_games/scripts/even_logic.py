# logic module for even game


def even_check(number):
    if (number % 2) == 0:
        return 'yes'
    else:
        return 'no'
